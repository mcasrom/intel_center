#!/usr/bin/env python3
import sqlite3
import os
from datetime import datetime

# RUTAS
DB_PATH = "/home/dietpi/intel_center_odroid/data/news.db"
# Carpeta donde Hugo guarda los posts
POSTS_DIR = "/home/dietpi/intel_center_odroid/blog/content/post/"

def generar_analisis_semanal():
    if not os.path.exists(DB_PATH): return
    
    # Generar nombre: YYMMDD-estrategico.md
    nombre_archivo = datetime.now().strftime("%y%m%d") + "-estrategico.md"
    REPORT_PATH = os.path.join(POSTS_DIR, nombre_archivo)
    
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Consulta de comparación: Semana 1 (0-7 días) vs Semana 2 (7-14 días)
    query = """
    SELECT 
        region, 
        AVG(CASE WHEN timestamp > datetime('now', '-7 days') THEN sentimiento END) as sem_1,
        AVG(CASE WHEN timestamp BETWEEN datetime('now', '-14 days') AND datetime('now', '-7 days') THEN sentimiento END) as sem_2,
        COUNT(CASE WHEN timestamp > datetime('now', '-7 days') THEN 1 END) as vol_sem_1
    FROM news 
    WHERE sentimiento != 0.0 
    GROUP BY region
    HAVING sem_1 IS NOT NULL;
    """
    
    cur.execute(query)
    filas = cur.fetchall()
    
    if not filas:
        print("[-] No hay datos suficientes para comparar semanas.")
        conn.close()
        return

    with open(REPORT_PATH, "w") as f:
        # Cabecera Hugo
        f.write(f"---\ntitle: \"Balance Estratégico Semanal: {datetime.now().strftime('%d/%m/%Y')}\"\ndate: {datetime.now().isoformat()}\n---\n\n")
        f.write("## 📉 Comparativa de Sentimiento Regional (7d vs 14d)\n\n")
        f.write("| Región | Actual (7d) | Previo (14d) | Tendencia | Volumen | Estado |\n")
        f.write("| :--- | :--- | :--- | :--- | :--- | :--- |\n")
        
        # Variables para el análisis de inteligencia
        regiones_deterioro = []
        regiones_mejora = []
        suma_sentimiento = 0
        total_eventos = 0
        
        for reg, s1, s2, vol in filas:
            s2 = s2 if s2 is not None else 0.0
            diff = s1 - s2
            suma_sentimiento += s1
            total_eventos += vol
            
            # Clasificación para inteligencia
            if diff > 0.05:
                trend = "📈 Mejorando"
                regiones_mejora.append(reg)
            elif diff < -0.05:
                trend = "📉 Deterioro"
                regiones_deterioro.append(reg)
            else:
                trend = "➡️ Estable"
            
            # Semáforo
            if s1 < -0.1: color = "🔴 Crítico"
            elif s1 > 0.1: color = "🟢 Positivo"
            else: color = "🟡 Neutral"
            
            f.write(f"| **{reg}** | {s1:.3f} | {s2:.3f} | {trend} | {vol} | {color} |\n")

        # --- SECCIÓN DE INTELIGENCIA ESTRATÉGICA ---
        f.write("\n### 🧠 Análisis de Situación\n\n")
        
        promedio_global = suma_sentimiento / len(filas) if filas else 0
        
        if not regiones_deterioro and not regiones_mejora:
            resumen = "Se observa un **estatismo atípico** en el pulso informativo global. "
        elif len(regiones_deterioro) > len(regiones_mejora):
            resumen = f"El vector de inteligencia muestra un **sesgo de deterioro**, liderado por tensiones en {', '.join(regiones_deterioro[:2])}. "
        else:
            resumen = f"Se detecta una **recuperación del sentimiento** en áreas clave como {', '.join(regiones_mejora[:2])}, sugiriendo una estabilización de la narrativa. "

        if promedio_global < 0:
            resumen += "La carga semántica general se mantiene en terreno negativo, lo que indica un clima de confrontación o crisis activa. "
        else:
            resumen += "El tono global vira hacia la neutralidad constructiva, con una reducción de la retórica hostil en los feeds monitorizados. "

        f.write(f"> {resumen}Este informe sintetiza la actividad de {total_eventos} eventos analizados por el nodo Odroid-C2.\n")

    conn.close()
    
    # --- MANTENIMIENTO: Conservar solo los últimos 4 informes estratégicos ---
    todos_los_estrat = sorted([f for f in os.listdir(POSTS_DIR) if "-estrategico.md" in f])
    if len(todos_los_estrat) > 4:
        for viejo in todos_los_estrat[:-4]:
            try:
                os.remove(os.path.join(POSTS_DIR, viejo))
                print(f"[-] Eliminado informe antiguo: {viejo}")
            except:
                pass

if __name__ == "__main__":
    generar_analisis_semanal()
