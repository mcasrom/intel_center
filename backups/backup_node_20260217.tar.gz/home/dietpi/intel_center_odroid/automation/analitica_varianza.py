#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sqlite3
import os
from datetime import datetime

# ========================================================
# CONFIGURACIÓN DE RUTAS
# ========================================================
BASE_DIR = "/home/dietpi/intel_center_odroid"
DB_PATH = os.path.join(BASE_DIR, "blog/data/intel_data.sqlite")
OUTPUT_PATH = os.path.join(BASE_DIR, "blog/content/post/analisis-varianza.md")

TABLA_NOTICIAS = "noticias"
COL_REGION = "region"
COL_TENSION = "tension"
COL_FECHA = "fecha"

def obtener_varianza():
    if not os.path.exists(DB_PATH):
        print(f"CRÍTICO: No se encuentra la DB en {DB_PATH}")
        return None

    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # QUERY: Regiones individuales + Fila GLOBAL al final
        query = f"""
        WITH datos AS (
            SELECT 
                {COL_REGION}, 
                AVG(CASE WHEN {COL_FECHA} >= datetime('now', '-1 day') THEN {COL_TENSION} END) as t_hoy,
                AVG(CASE WHEN {COL_FECHA} < datetime('now', '-1 day') AND {COL_FECHA} >= datetime('now', '-2 days') THEN {COL_TENSION} END) as t_ayer
            FROM {TABLA_NOTICIAS}
            GROUP BY {COL_REGION}
        )
        SELECT * FROM datos WHERE t_hoy IS NOT NULL AND t_ayer IS NOT NULL
        UNION ALL
        SELECT 
            'GLOBAL (Media)', 
            AVG(CASE WHEN {COL_FECHA} >= datetime('now', '-1 day') THEN {COL_TENSION} END),
            AVG(CASE WHEN {COL_FECHA} < datetime('now', '-1 day') AND {COL_FECHA} >= datetime('now', '-2 days') THEN {COL_TENSION} END)
        FROM {TABLA_NOTICIAS}
        WHERE {COL_FECHA} >= datetime('now', '-2 days');
        """
        
        cursor.execute(query)
        resumen = cursor.fetchall()
        conn.close()
        return resumen

    except Exception as e:
        print(f"ERROR: {e}")
        return None

def generar_markdown(datos):
    if not datos:
        print("AVISO: Datos insuficientes para generar varianza.")
        return
    
    ahora = datetime.now().strftime("%Y-%m-%dT%H:%M:%S+01:00")
    
    try:
        with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
            f.write("---\n")
            f.write("title: \"Análisis de Varianza de Tensión Regional\"\n")
            f.write(f"date: {ahora}\n")
            f.write("report_types: [\"metodologia\"]\n")
            f.write("weight: 10\n")
            f.write("---\n\n")

            f.write("### 📊 Evolución de la Tensión\n")
            f.write("| Región | Tensión Hoy | Tensión Ayer | Delta (Δ) | Tendencia |\n")
            f.write("|:---|:---:|:---:|:---:|:---:|\n")
            
            for reg, hoy, ayer in datos:
                delta = hoy - ayer
                # Estilo diferenciado para la fila Global
                is_global = "GLOBAL" in reg
                prefix = "**" if is_global else ""
                
                if delta > 0.05: status = "🔴 **Escalada**"
                elif delta > 0.01: status = "🟡 Incremento"
                elif delta < -0.05: status = "🟢 **Distensión**"
                elif delta < -0.01: status = "🔹 Descenso"
                else: status = "⚪ Estable"
                
                f.write(f"| {prefix}{reg}{prefix} | {hoy:.4f} | {ayer:.4f} | {delta:+.4f} | {status} |\n")
            
            f.write("\n\n---\n*Generado por el Módulo de Analítica del Nodo Odroid-C2.*")
        print(f"ÉXITO: Informe generado con Media Global.")

    except Exception as e:
        print(f"ERROR: {e}")

if __name__ == "__main__":
    generar_markdown(obtener_varianza())
