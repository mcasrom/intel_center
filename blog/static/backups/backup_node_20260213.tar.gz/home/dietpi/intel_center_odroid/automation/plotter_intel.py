import pandas as pd
import matplotlib.pyplot as plt
import os
import sys
import datetime

BASE_DIR = "/home/dietpi/intel_center_odroid"
USA_CSV = os.path.join(BASE_DIR, "data/usa_trend.csv")
SPAIN_CSV = os.path.join(BASE_DIR, "data/spain_trend.csv")

def generar_grafica():
    try:
        if not os.path.exists(USA_CSV) or not os.path.exists(SPAIN_CSV):
            return

        df_usa = pd.read_csv(USA_CSV).tail(24)
        df_spain = pd.read_csv(SPAIN_CSV).tail(24)

        plt.figure(figsize=(10, 5))
        plt.style.use('dark_background')

        plt.plot(df_usa['timestamp'], df_usa['avg_sentiment'], label='USA', color='#3498db', linewidth=2, marker='o', markersize=4)
        plt.plot(df_spain['timestamp'], df_spain['avg_sentiment'], label='ESPAÑA', color='#e74c3c', linewidth=2, marker='o', markersize=4)

        plt.axhline(0, color='white', linestyle='--', alpha=0.3)
        plt.title('EVOLUCIÓN DEL SENTIMIENTO GEOPOLÍTICO', color='#2ecc71', fontsize=14)
        plt.xticks(rotation=45, ha='right', fontsize=8)
        plt.legend(loc='upper left')
        plt.grid(alpha=0.1)
        plt.tight_layout()

        # AQUÍ LA CLAVE: Si el bash le pasa un nombre, lo usa.
        if len(sys.argv) > 1:
            nombre_img = sys.argv[1]
        else:
            # Fallback por si lo lanzas a mano
            nombre_img = datetime.datetime.now().strftime("%y%m%d_%H%M_trend.png")

        OUTPUT_IMG = os.path.join(BASE_DIR, "blog/static/images/", nombre_img)
        os.makedirs(os.path.dirname(OUTPUT_IMG), exist_ok=True)
        plt.savefig(OUTPUT_IMG)
        # También guardamos trend.png para el index del blog
        plt.savefig(os.path.join(BASE_DIR, "blog/static/images/trend.png"))
        plt.close()

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    generar_grafica()
