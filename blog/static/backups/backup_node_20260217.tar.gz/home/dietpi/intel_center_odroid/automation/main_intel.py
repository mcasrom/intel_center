#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, feedparser, sqlite3, json, pytz, glob
from datetime import datetime
# --- CONEXIÓN CON EL CEREBRO ---
from sentiment_engine import analizar_sentimiento 

# --- CONFIGURACIÓN DE RUTAS ---
BASE_DIR = "/home/dietpi/intel_center_odroid"
DB_PATH = os.path.join(BASE_DIR, "data/news.db")
JSON_OUTPUT = os.path.join(BASE_DIR, "blog/data/hotspots.json")
POSTS_DIR = os.path.join(BASE_DIR, "blog/content/post/")

# Marcadores de tiempo
ahora_utc = datetime.now()
timestamp_img = ahora_utc.strftime("%y%m%d_%H%M") 
nombre_imagen_dinamica = f"{timestamp_img}_trend.png"

# Datos de tendencia y zona horaria
USA_CSV = os.path.join(BASE_DIR, "data/usa_trend.csv")
SPAIN_CSV = os.path.join(BASE_DIR, "data/spain_trend.csv")
ZONA_LOCAL = pytz.timezone("Europe/Madrid")
ahora_local = datetime.now(ZONA_LOCAL)
fecha_s = ahora_local.strftime("%Y-%m-%d %H:%M")

FEEDS = {
    "USA_NORTE": "https://www.theguardian.com/us-news/rss",
    "ESPAÑA": "https://elpais.com/rss/politica/portada.xml",
    "ARGENTINA": "https://www.clarin.com/rss/politica/",
    "BRASIL": "https://agenciabrasil.ebc.com.br/rss/ultimasnoticias/feed.xml",
    "Europa_DW": "https://rss.dw.com/rdf/rss-en-top",
    "Rusia_Eurasia": "https://tass.com/rss/v2.xml",
    "Medio_Oriente": "https://www.aljazeera.com/xml/rss/all.xml",
    "Asia_Nikkei": "https://asia.nikkei.com/rss/feed/nar",
    "Africa_Sahel": "https://www.africanews.com/feed/"
}

COORDS = {
    "USA_NORTE": [40.0, -100.0], "ESPAÑA": [40.4, -3.7], "ARGENTINA": [-34.0, -64.0],
    "BRASIL": [-10.0, -55.0], "Europa_DW": [50.0, 10.0], "Rusia_Eurasia": [60.0, 90.0],
    "Medio_Oriente": [25.0, 45.0], "Asia_Nikkei": [35.0, 135.0], "Africa_Sahel": [15.0, 15.0]
}

BUSQUEDA_LIDERES = {
    "Donald Trump": ["trump", "potus", "maga"],
    "Vladimir Putin": ["putin", "kremlin"],
    "Xi Jinping": ["xi jinping", "jinping", "beijing"],
    "Pedro Sánchez": ["sánchez", "moncloa"],
    "Javier Milei": ["milei", "casa rosada"]
}

def ejecutar():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS news 
        (region TEXT, title TEXT, link TEXT UNIQUE, sentimiento REAL, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)
    """)

    alertas, electoral, resumen, lideres = [], [], [], []

    for reg, url in FEEDS.items():
        feed = feedparser.parse(url)
        for e in feed.entries[:12]:
            title = e.title
            link = e.link
            low_title = title.lower()
            
            encontrado_lider = False
            for nombre, claves in BUSQUEDA_LIDERES.items():
                if any(x in low_title for x in claves):
                    lideres.append(f"👤 **{nombre}**: {title} ([Link]({link}))")
                    encontrado_lider = True
                    break

            if not encontrado_lider:
                if any(x in low_title for x in ["war", "military", "conflict", "attack", "nuclear", "missile"]):
                    alertas.append(f"🚩 [ALERTA] {reg}: {title} ([Link]({link}))")
                elif any(x in low_title for x in ["election", "voto", "campaña", "electoral", "pp", "psoe"]):
                    electoral.append(f"🗳️ [ELECTORAL] {reg}: {title} ([Link]({link}))")
                else:
                    resumen.append(f"[{reg}]: {title} ([Link]({link}))")

            # Análisis de sentimiento
            puntaje = analizar_sentimiento(title)
            cur.execute("INSERT OR IGNORE INTO news (region, title, link, sentimiento) VALUES (?,?,?,?)", (reg, title, link, puntaje))

    conn.commit()

    def get_avg(region):
        cur.execute("SELECT AVG(sentimiento) FROM news WHERE region=? AND sentimiento != 0.0 AND timestamp > datetime('now','-12 hours')", (region,))
        res = cur.fetchone()[0]
        return round(res if res is not None else 0.0, 4)

    s_usa, s_esp = get_avg("USA_NORTE"), get_avg("ESPAÑA")
    
    for csv_path, val in [(USA_CSV, s_usa), (SPAIN_CSV, s_esp)]:
        with open(csv_path, "a") as f: f.write(f"{fecha_s},{val}\n")

    hotspots = []
    cur.execute("SELECT region, AVG(sentimiento), COUNT(*) FROM news WHERE sentimiento != 0.0 AND timestamp > datetime('now','-72 hours') GROUP BY region")
    
    for r, sent, count in cur.fetchall():
        if r in COORDS:
            color_nodo = "#f1c40f"
            if sent < -0.05: color_nodo = "#e74c3c"
            elif sent > 0.05: color_nodo = "#2ecc71"

            hotspots.append({
                "name": r, "lat": COORDS[r][0], "lon": COORDS[r][1],
                "intensity": min(count, 15), "color": color_nodo,
                "sentiment_index": round(sent, 4)
            })
    
    with open(JSON_OUTPUT, "w") as j:
        json.dump(hotspots, j, indent=4)

    # --- 4. GENERACIÓN DE INFORME MD ---
    # Nombre con hora para evitar sobreescritura (Feed dinámico)
    nombre_diario = datetime.now().strftime("%y%m%d_%H%M") + "-noticias.md"
    DIARIO_PATH = os.path.join(POSTS_DIR, nombre_diario)

    with open(DIARIO_PATH, "w") as f:
        # Frontmatter para Hugo
        f.write("---\n")
        f.write(f"title: \"Inteligencia OSINT: {datetime.now().strftime('%d/%m/%Y %H:%M')}\"\n")
        f.write(f"date: {datetime.now().isoformat()}\n")
        f.write("report_types: [\"Diario\"]\n")
        f.write("---\n\n")

        # Resumen Operativo (Separador 'more' para visibilidad en web)
        f.write("### ⚡ Resumen Operativo\n")
        f.write(f"Actualización del nodo Odroid-C2. Análisis de sentimiento y tendencias globales generado el {datetime.now().strftime('%d/%m/%Y a las %H:%M')}.\n\n")
        f.write("\n\n")

        # Cuerpo
        f.write("🛡️ ESTADO DEL NODO\n\n| Indicador | Valor |\n| :--- | :--- |\n")
        f.write(f"| STATUS | 🟢 OPERATIVO |\n| ÚLTIMA SYNC | {fecha_s} |\n| HARDWARE | Odroid-C2-Madrid |\n\n")
        
        f.write("📊 RADARES DE TENDENCIA\n\n| Región | Sentimiento |\n| :--- | :--- |\n")
        f.write(f"| 🇺🇸 USA | {s_usa} |\n| 🇪🇸 ESPAÑA | {s_esp} |\n\n")
        
        f.write("📈 Evolución de Tendencia\n\n")
        f.write(f"![Gráfica de Tendencias](/images/{nombre_imagen_dinamica})\n\n")
        
        f.write("👤 MOVIMIENTOS DE LÍDERES MUNDIALES\n\n")
        if lideres:
            for l in lideres[:10]: f.write(f"{l}  \n")
        else:
            f.write("No se detectan movimientos directos de mandatarios clave.  \n")

        f.write("\n⚡ ALERTAS CRÍTICAS\n\n")
        if alertas:
            for a in alertas[:6]: f.write(f"{a}  \n")
        else:
            f.write("No se han detectado eventos críticos.  \n")

        f.write("\n🌍 RESUMEN GLOBAL\n\n")
        for r in resumen[:12]: f.write(f"{r}  \n")

    # --- SISTEMA DE ROTACIÓN (Higiene del Nodo) ---
    viejos = sorted(glob.glob(os.path.join(POSTS_DIR, "*-noticias.md")), reverse=True)
    if len(viejos) > 20:
        for f_viejo in viejos[20:]:
            try:
                os.remove(f_viejo)
            except:
                pass

    # Limpieza de DB y cierre
    cur.execute("DELETE FROM news WHERE timestamp < datetime('now','-15 days')")
    conn.commit()
    conn.close()

if __name__ == "__main__":
    ejecutar()
