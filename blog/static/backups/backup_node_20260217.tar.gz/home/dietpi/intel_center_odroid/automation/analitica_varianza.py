#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sqlite3
import os
import sys
from datetime import datetime

# ========================================================
# CONFIGURACIÓN DE RUTAS (AJUSTADAS A TU ODROID-C2)
# ========================================================
BASE_DIR = "/home/dietpi/intel_center_odroid"
DB_PATH = os.path.join(BASE_DIR, "blog/data/intel_data.sqlite")
OUTPUT_PATH = os.path.join(BASE_DIR, "blog/content/post/analisis-varianza.md")

# Nombres de tu esquema (Cámbialos si son distintos)
TABLA_NOTICIAS = "noticias"
COL_REGION = "region"
COL_TENSION = "tension"  # o 'sentiment'
COL_FECHA = "fecha"

def obtener_varianza():
    """Calcula la diferencia de tensión entre hoy y ayer."""
    if not os.path.exists(DB_PATH):
        print(f"CRÍTICO: No se encuentra la DB en {DB_PATH}")
        return None

    try:
        # Conexión estándar (SQLite en Odroid gestiona bien el acceso concurrente)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # QUERY ANALÍTICA:
        # t_hoy: Media de las últimas 24h
        # t_ayer: Media de las 24h a 48h anteriores
        query = f"""
        SELECT 
            {COL_REGION}, 
            AVG(CASE WHEN {COL_FECHA} >= datetime('now', '-1 day') THEN {COL_TENSION} END) as t_hoy,
            AVG(CASE WHEN {COL_FECHA} < datetime('now', '-1 day') AND {COL_FECHA} >= datetime('now', '-2 days') THEN {COL_TENSION} END) as t_ayer
        FROM {TABLA_NOTICIAS}
        GROUP BY {COL_REGION}
        HAVING t_hoy IS NOT NULL AND t_ayer IS NOT NULL;
        """
        
        cursor.execute(query)
        resumen = cursor.fetchall()
        conn.close()
        return resumen

    except sqlite3.Error as e:
        print(f"ERROR SQLITE: {e}")
        return None
    except Exception as e:
        print(f"ERROR INESPERADO: {e}")
        return None

def generar_markdown(datos):
    """Genera el post para Hugo con los resultados analíticos."""
    if not datos:
        print("AVISO: No hay datos suficientes (hoy/ayer) para generar varianza.")
        return
    
    ahora = datetime.now().strftime("%Y-%m-%dT%H:%M:%S+01:00")
    
    try:
        with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
            # Frontmatter de Hugo
            f.write("---\n")
            f.write("title: \"Análisis de Varianza de Tensión Regional\"\n")
            f.write(f"date: {ahora}\n")
            f.write("report_types: [\"metodologia\"]\n")
            f.write("tags: [\"analitica\", \"varianza\", \"odroid-c2\"]\n")
            f.write("weight: 10\n")
            f.write("summary: \"Comparativa de tensión narrativa entre las últimas 24h y el periodo anterior.\"\n")
            f.write("---\n\n")

            f.write("### 📊 Evolución de la Tensión por Región\n")
            f.write("Este informe compara la **Tensión Media** actual frente a las 24 horas anteriores para detectar escaladas de conflicto.\n\n")
            
            f.write("| Región | Tensión Hoy | Tensión Ayer | Delta (Δ) | Tendencia |\n")
            f.write("|:---|:---:|:---:|:---:|:---:|\n")
            
            for reg, hoy, ayer in datos:
                delta = hoy - ayer
                
                # Definición de umbrales de alerta
                if delta > 0.05:
                    status = "🔴 **Escalada Crítica**"
                elif delta > 0.01:
                    status = "🟡 Incremento"
                elif delta < -0.05:
                    status = "🟢 **Distensión Fuerte**"
                elif delta < -0.01:
                    status = "🔹 Descenso"
                else:
                    status = "⚪ Estable"
                
                # Escribir fila de tabla
                f.write(f"| {reg} | {hoy:.4f} | {ayer:.4f} | {delta:+.4f} | {status} |\n")
            
            f.write("\n\n---\n")
            f.write(f"*Informe generado automáticamente por el Módulo de Analítica del Nodo Odroid-C2 el {datetime.now().strftime('%d/%m/%Y %H:%M')}.*")
        
        print(f"ÉXITO: Informe generado en {OUTPUT_PATH}")

    except Exception as e:
        print(f"ERROR AL ESCRIBIR MARKDOWN: {e}")

if __name__ == "__main__":
    print(f"--- Iniciando Módulo de Analítica [{datetime.now()}] ---")
    resultados = obtener_varianza()
    generar_markdown(resultados)
