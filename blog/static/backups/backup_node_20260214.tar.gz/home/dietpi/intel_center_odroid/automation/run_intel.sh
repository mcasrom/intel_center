#!/bin/bash
BASE_DIR="/home/dietpi/intel_center_odroid"
AUTO_DIR="$BASE_DIR/automation"
BLOG_DIR="$BASE_DIR/blog"

# 1. EJECUTAR MOTOR (Descarga y analiza sentimientos)
python3 $AUTO_DIR/main_intel.py

# 2. SINCRONIZAR IMAGEN (Captura el nombre dinámico del último informe)
ULTIMO_POST=$(ls -t $BLOG_DIR/content/post/*.md | head -n 1)
NOMBRE_IMG=$(grep "!\[Gráfica" $ULTIMO_POST | cut -d'/' -f3 | tr -d ')')

# 3. EJECUTAR PLOTTER con el nombre exacto
python3 $AUTO_DIR/plotter_intel.py $NOMBRE_IMG

# 3.5 GENERAR ANÁLISIS ESTRATÉGICO (Solo si es necesario o en cada ciclo)
python3 $AUTO_DIR/analista_historico.py

# 4. GENERAR SITIO Y SUBIR A GITHUB
cd $BLOG_DIR
/usr/local/bin/hugo --gc --cleanDestinationDir
git add .
git commit -m "Auto-update: $NOMBRE_IMG"
git push origin main

# 5. EJECUTAR BACKUP INTEGRAL (Integrado de backup_configs.sh)
bash $AUTO_DIR/backup_configs.sh

echo "[✅] CICLO COMPLETO: Datos procesados, Gráfica generada y Nodo respaldado."
